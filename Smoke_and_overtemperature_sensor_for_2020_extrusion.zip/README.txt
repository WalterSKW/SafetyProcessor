                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2548411
Smoke and overtemperature sensor for 2020 extrusion by WalterSKW is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a more elaborated detection unit to be mounted on critical places in the printer like 
- Electronic box : detection of smoking/burning heated bed connectors, failing cheap PSU ...
- Printing area (enclosed)

The unit has an FC22 print with a gas detection unit on it like the MQ135 ( suitable for detecting  of NH3,NOx, alcohol, Benzene, smoke,CO2) , an NTC for overtemperature detection and a LED to signal fault conditions.
See detector specs [here](https://www.olimex.com/Products/Components/Sensors/SNS-MQ135/resources/SNS-MQ135.pdf)
Everything has a quite tight fit.
The holes for the NTC are placed so that they land on the 2 outer pins of the 6pin connector. Easy to solder like that!
I used standard network cable with one pair for the NTC, 2 wires for GND, 2 wires for and Vcc, one for the LED and the remaining one for the Digital (or analog) out
Keep in mind that the detectormodule itself contains a heating element that draws 150mA (see specs). I didn't check the effects on PLA when mounted in the warm top section of an enclosed printer.

I printed this with a 0,6mm nozzle and 0,2mm layers in clear PETG for the housing. The gas detector unit has also 2 LEDs on board : power on and alarm. These are visible through the housing.
Housing and mounting are screwed together using standard 20mm M3 screws. The bottom part has a smaller hole for the screws so they can be self tapping. 

** Modification 20170923 **
Cut out a hole on the bottom for easy access to the potmeter when using digital out.